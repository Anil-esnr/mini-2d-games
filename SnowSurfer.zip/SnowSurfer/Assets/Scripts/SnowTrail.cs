using UnityEngine;

public class SnowTrail : MonoBehaviour
{
    [SerializeField] ParticleSystem SnowParticles;



    void OnCollisionEnter2D(Collision2D collision)
    {
        int layerIndeks = LayerMask.NameToLayer("Floor");
        if (collision.gameObject.layer == layerIndeks)
        {
            SnowParticles.Play();
        }
    }
    void OnCollisionExit2D(Collision2D collision)
    {
        int layerIndeks = LayerMask.NameToLayer("Floor");
        if (collision.gameObject.layer == layerIndeks)
        {
            SnowParticles.Stop();
        }
    }
}
