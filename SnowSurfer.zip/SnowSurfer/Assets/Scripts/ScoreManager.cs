using UnityEngine;
using TMPro;
using Unity.VisualScripting;
public class ScoreManager : MonoBehaviour
{
    int score = 0;
    [SerializeField] TextMeshProUGUI scoreText;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
     public void AddScore(int additionalScore)
    {
        score += additionalScore;
        scoreText.text = "Score: " + score + " !";
    }


}
