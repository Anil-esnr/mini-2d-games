using UnityEngine;
using UnityEngine.SceneManagement;
public class CrashDetector : MonoBehaviour
{
    [SerializeField] float restartDelay = 1f;
    [SerializeField] ParticleSystem crashParticles;
    PlayerController playerController;
    void Start()
    {
        playerController = FindFirstObjectByType<PlayerController>();
    }
        private void OnTriggerEnter2D(Collider2D collision)
    {
        int layerIndeks = LayerMask.NameToLayer("Floor");
        if (collision.gameObject.layer == layerIndeks)
        {
            playerController.DisableControl();
            crashParticles.Play();
            Invoke("ReloadScene", restartDelay);

        }

    }
    void ReloadScene()
    {
        SceneManager.LoadScene(0);
    }



}
