using UnityEngine;
using UnityEngine.SceneManagement;
public class FinishLine : MonoBehaviour
{
    [SerializeField] float restartDelay = 1f;
    [SerializeField] ParticleSystem finishParticles;
        private void OnTriggerEnter2D(Collider2D collision)
    {
        int layerIndeks = LayerMask.NameToLayer("Player");
        if (collision.gameObject.layer == layerIndeks)
        {
            finishParticles.Play();
            Invoke("ReloadScene", restartDelay );
        }
    }
    void ReloadScene()
    {
        SceneManager.LoadScene(0);
    }
}
