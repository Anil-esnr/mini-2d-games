using UnityEngine;

public class PowerupManager : MonoBehaviour
{
    [SerializeField] PowerUpSO powerup;
     PlayerController player;
    SpriteRenderer spriteRenderer;
    float timeLeft;

    void Start()
    {
        player = FindFirstObjectByType<PlayerController>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        timeLeft = powerup.GetTime();
    }

    void Update()
    {
        CountdownTimer();
        
    }
    void CountdownTimer()
    {
        if (spriteRenderer.enabled == false)
        {
            if (timeLeft > 0)
            {
                timeLeft -= Time.deltaTime;

                if (timeLeft <= 0)
                {
                    player.DeactivePowerup(powerup);
                }
            }
            
        }
    }
    void OnTriggerEnter2D(Collider2D collision)
    {
        int layerIndeks = LayerMask.NameToLayer("Player");
        if (collision.gameObject.layer == layerIndeks && spriteRenderer.enabled)
        {
            spriteRenderer.enabled = false;
            player.ActivePowerup(powerup);

        }

    }


}
