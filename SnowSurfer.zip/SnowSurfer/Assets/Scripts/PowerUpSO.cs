using UnityEngine;

[CreateAssetMenu(fileName = "PowerUp", menuName = "PowerUpSO")]
public class PowerUpSO : ScriptableObject
{
    [SerializeField] string powerupType;
    [SerializeField] float valueChange;
    [SerializeField] float time;
    public string GetPowerupType()
    {
        return powerupType;
    }
    public float GetValueChange()
    {
        return valueChange;
    }
    public float GetTime()
    {
        return time;
    }
}
